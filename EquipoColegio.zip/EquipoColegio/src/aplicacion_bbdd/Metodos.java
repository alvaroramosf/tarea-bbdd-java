package aplicacion_bbdd;

public class Metodos {

}
